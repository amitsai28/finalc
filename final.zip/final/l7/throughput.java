//package comp_networks;
import java.util.*;
import java.lang.*;
public class throughput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("do you want different physical networks");
		Scanner s=new Scanner(System.in);
		long a=16777214;
		long b=65534;
		long c=254;
		double no_classes,trput,no_sub;
		String input;
		float hosts;
		input=s.next();
		if(input.equals("no"))
		{
			System.out.println("enter the number of hosts");
			hosts=Float.parseFloat(s.next());
			no_classes=Math.ceil(hosts/a);
			trput=(hosts/(a*no_classes))*100;
			System.out.println("for class A: "+"  "+"no of classes:  "+no_classes+"throughput:  "+trput);
			no_classes=Math.ceil(hosts/b);
			trput=(hosts/(b*no_classes))*100;
			System.out.println("for class B: "+"  "+"no of classes:  "+no_classes+"throughput:  "+trput);
			no_classes=Math.ceil(hosts/c);
			trput=(hosts/(c*no_classes))*100;
			System.out.println("for class C: "+"  "+"no of classes:  "+no_classes+"throughput:  "+trput);
		}
		else
		{
			int nets;
			System.out.println("enter the number of networks");
					nets=s.nextInt();
					System.out.println("enter the no of hosts in each network");
					hosts=Float.parseFloat(s.next());
					no_sub=Math.floor(a/hosts);
					trput=(hosts*nets/a)*100;
					System.out.println("for class A(subnet): "+"  "+"no of subnets:  "+no_sub+"throughput:  "+trput);
					if(hosts<b)
					{
					no_sub=Math.floor(b/hosts);
					trput=(hosts*nets/b)*100;
					System.out.println("for class B(subnet): "+"  "+"no of subnets:  "+no_sub+"throughput:  "+trput);
					}
					else if(hosts>b)
					{
						no_classes=Math.ceil(hosts/b);
						trput=((hosts*nets)/(no_classes*nets*b))*100;
						System.out.println("for class C(supernet): "+"  "+"no of classes:  "+no_classes*nets+"throughput:  "+trput);
						
					}
					

					if(hosts<c)
					{
					no_sub=Math.floor(c/hosts);
					trput=(hosts*nets/c)*100;
					System.out.println("for class C(subnet): "+"  "+"no of subnets:  "+no_sub+"throughput:  "+trput);
					}
					else if(hosts>c)
					{
						no_classes=Math.ceil(hosts/c);
						trput=((hosts*nets)/(no_classes*nets*c))*100;
						System.out.println("for class C(supernet): "+"  "+"no of classes:  "+no_classes*nets+"throughput:  "+trput);
						
					}
					

		}
		
		

	}

}
