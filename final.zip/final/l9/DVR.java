import java.util.Scanner;

public class DVR {
    public static void main(String args[]){
        System.out.println("routers no \t");
        Scanner sc=new Scanner(System.in);
        int n1=sc.nextInt();
        int adj[][] = new int[n1][n1];
        System.out.println("enter weights");
        for(int i=0;i<n1;i++){
            for(int j=0;j<n1;j++){
                String input = sc.next();
                if(input.equals("i"))  adj[i][j] = 999;
                else adj[i][j] = Integer.parseInt(input);
            }
        }
        int routingtable[][][]=new int[n1][n1][3];
        int previous[][] = new int[n1][n1];
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++) {
                routingtable[i][j][0] = j;
                routingtable[i][j][1] = adj[i][j];
                previous[i][j] = adj[i][j];
                if(adj[i][j]!=999)
                    routingtable[i][j][2] = j;
                else
                    routingtable[i][j][2] = -1;
            }
        }
        for(int a=0;a<n1-2;a0++){
            for(int i=0;i<n1;i++){
                for(int j=0;j<n1;j++){
                    if(i==j){
                        routingtable[i][j][1] = 0;
                        routingtable[i][j][2] = i;
                        continue;
                    }
                    int min_index=-1;
                    int min=999;
                    for(int k=0;k<n1;k++){
                        if(i==k) continue;
                        if(adj[i][k]==999) continue;
                        if(min>adj[i][k]+previous[k][j]) {
                            min = adj[i][k] + previous[k][j];
                            minindex = k;
                        }
                    }
                    routing_table[i][j][1] = min;
                    routing_table[i][j][2] = minindex;
                }
            }
            for(int i=0;i<n1;i++){
                for(int j=0;j<n1;j++){
                    previous[i][j]=routingtable[i][j][1];
                }
            }
        }
        System.out.println("following is routing table");
        for(int i=0;i<n1;i++){
            System.out.println("Route table at \t"+(char)(i+65)+" :");
            System.out.println("Destination\tDistance\tNext Hop");
            for(int j=0;j<n1;j++){
                System.out.println("\t"+(char)(routingtable[i][j][0]+65)
                        +"\t\t\t"+routingtable[i][j][1]
                        +"\t\t\t"+(char)(routingtable[i][j][2]+65));
            }
            System.out.println("\n\n\n");
        }
    }
}
