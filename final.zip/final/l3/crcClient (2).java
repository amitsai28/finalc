import java.io.*;
import java.net.*;
import java.util.*;

public class crcClient{
    public static void main(String args[]) throws IOException {
        Socket sc = new Socket("localhost",5000);
        DataInputStream din=new DataInputStream(sc.getInputStream());
        DataOutputStream dout=new DataOutputStream(sc.getOutputStream());
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
       // System.out.println("enter the total number of bits u received");
        int n=din.readInt();
        int crc[]=new int[n];
        int rem[]=new int[n];


System.out.println(" data received is ");
        for(int i=0; i<n; i++){
            crc[i]=din.readInt();
        System.out.println(crc[i]);}

       int divisor_bits=din.readInt();
        int divisor[]=new int[divisor_bits];

        System.out.println(" Divisor bits are : ");
        for(int i=0; i<divisor_bits; i++) {
            divisor[i] = din.readInt();
            System.out.println(divisor[i]);

        }
        for(int j=0; j<crc.length; j++){
            rem[j] = crc[j];
        }

        rem=divide(crc, divisor, rem);

        for(int i=0; i< rem.length; i++)
        {
            if(rem[i]!=0)
            {
                System.out.println("Error");
                break;
            }
            if(i==rem.length-1)
                System.out.println("No Error");
        }

        System.out.println("THANK YOU.... :)");

    }
    static int[] divide(int div[],int divisor[], int rem[])
    {
        int cur=0;
        while(true)
        {
            for(int i=0;i<divisor.length;i++)
                rem[cur+i]=(rem[cur+i]^divisor[i]);

            while(rem[cur]==0 && cur!=rem.length-1)
                cur++;

            if((rem.length-cur)<divisor.length)
                break;
        }
        return rem;
    }
}
