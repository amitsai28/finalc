import java.io.*;  
import java.net.*;  
public class Parity_receiver{  
public static void main(String[] args) {  
try{      
//Socket s=new Socket("192.168.43.251",6666);  
	Socket s=new Socket("localhost",6666); 
	System.out.println("Connected........");
	DataInputStream dis=new DataInputStream(s.getInputStream());  


	int[][] data=new int[40][9];
	int len=Integer.parseInt((String)dis.readUTF());
	for(int i=0;i<len;i++)
	{
		for(int j=0;j<9;j++)
		{
			String  str=(String)dis.readUTF();  
			data[i][j]=Integer.parseInt(str);
			System.out.print(data[i][j]);
		}
		System.out.println();
	}
	
	int i,j,one_count=0,one_count_col=0,q=0,k;
	// manipulating the data for checking weather working fine or not
	//data[0][0]=1;
	//data[0][2]=1;
	
//	data[1][0]=1;
	//data[1][2]=1;
	// FOR ROW CHECKING
	for(i=0;i<len;i++)
	{
		for(j=0;j<8;j++)
		{
			if(data[i][j]==1)
				one_count++;
		}
		if(data[i][8] != (one_count%2))
		{
			System.out.println("unsuccesful! at row number "+i);
			q=1;
			//break;
		}
		one_count=0;
	}
	int temp=0;
	if(q==0)
	{
		for(i=0;i<len;i++)
		{
			for(j=0;j<8;j++)
			{
				temp=temp+((int)Math.pow(2,7-j)*data[i][j]);
			}
			System.out.print((char)temp);
			temp=0;
		}
		System.out.println();
		System.out.println("data sent succesfully!!");
	}
	
	s.close();
	}
	catch(Exception e){System.out.println(e);}  
	}  
}  