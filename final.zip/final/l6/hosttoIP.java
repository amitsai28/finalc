import java.net.UnknownHostException;
import java.util.Scanner;

public class hosttoIP {
    public static void main(String args[]) throws UnknownHostException {
        System.out.print("domain :\t");
        Scanner sc = new Scanner(System.in);
        String domain=sc.next();
        String host1 = java.net.InetAddress.getByName(domain).getHostAddress();
        System.out.println("HostIP\t"+host1);
    }
}
