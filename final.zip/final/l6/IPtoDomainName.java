import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

public class IPtoDomainName {
    public static void main(String args[])throws UnknownHostException {
        System.out.print("Enter ip :\t");
        Scanner sc = new Scanner(System.in);
        String ip1 = sc.next();
        InetAddress inetAddress = InetAddress.getByName(ip);
        String hostname1 = inetAddress.getHostName();
        System.out.println("Host Name :\t"+hostname1);
    }
}
